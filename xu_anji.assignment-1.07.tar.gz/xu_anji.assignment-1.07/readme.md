axu@iastate.edu
THis is Spring 2022 COMS327 HW7

Setup:
"make all" to complie the code
"./poke327" to start the game.
"make clean" to removing all generated files

Started with professors code 1.06
Wild Pokemons in the tall grass
Press ESC To Exit Battle
