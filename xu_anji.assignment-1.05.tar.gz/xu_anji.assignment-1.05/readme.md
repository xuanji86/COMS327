axu@iastate.edu
THis is Spring 2022 COMS327 HW5

Setup:
"make all" to complie the code
"./poke327" to start the game.
"make clean" to removing all generated files

"h" is hikers
"r" is rivals
"p" is pacers
"w" is wanderers
"s" is stationaries
"n" is random walkers

7 or y Attempt to move PC one cell to the upper left
8 or k Attempt to move PC one cell up.
9 or u Attempt to move PC one cell to the upper right.
6 or l Attempt to move PC one cell to the right.
3 or n Attempt to move PC one cell to the lower right.
2 or j Attempt to move PC one cell down.
1 or b Attempt to move PC one cell to the lower left.
4 or h Attempt to move PC one cell to the left.
'>' enter building
'<' leave building
q quit the game
esc When displaying trainer list or in the battle, return to character control(When NPCs are defeated, they will be remove from the map).
