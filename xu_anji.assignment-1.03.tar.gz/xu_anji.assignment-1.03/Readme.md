axu@iastate.edu
THis is Spring 2022 COMS327 HW3

Project description:
This project auto generates the distance maps for current PC and other players. 
There are two maps generated each time: rival, hiker.
The core algorithm is dijkstra_cost() based on dijkstra algorithm to find the shorest path to reach the points on the map.

Setup:
"make all" to complie the code
"./poke327" to start the game.

N is for display the map on the north of the current map
S is for display the map on the south of the current map
E is for display the map on the east of the current map
W is for display the map on the west of the current map
F is for fly to (x,y) of the world
Q is for quit the game

