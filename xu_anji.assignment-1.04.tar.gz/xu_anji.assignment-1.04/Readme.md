axu@iastate.edu
THis is Spring 2022 COMS327 HW4

Setup:
"make all" to complie the code
"./poke327" to start the game.
"make clean" to removing all generated files

N is for display the map on the north of the current map
S is for display the map on the south of the current map
E is for display the map on the east of the current map
W is for display the map on the west of the current map
F is for fly to (x,y) of the world
Q is for quit the game

"h" is hikers
"r" is rivals
"p" is pacers
"w" is wanderers
"s" is stationaries
"n" is random walkers

Input the number of npc you want to add when you see "--numtrainer"
