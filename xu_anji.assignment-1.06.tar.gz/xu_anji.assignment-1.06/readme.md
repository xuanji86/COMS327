axu@iastate.edu
THis is Spring 2022 COMS327 HW6

Setup:
"make all" to complie the code
"./poke327" to start the game.
"make clean" to removing all generated files

Started with professors code 1.05
Enter the file name you want to parse excluding the extension to start
